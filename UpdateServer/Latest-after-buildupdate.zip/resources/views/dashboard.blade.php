<x-app-layout>
    {{-- Set the header content for the layout (uses light background, dark+bold text) --}}
    <x-slot name="header">
        {{ __('پیشخوان کاربری') }}
    </x-slot>

    {{-- Main content area (dark background provided by app.blade.php body) --}}
    {{-- Set default text color for this scope to dark, suitable for light cards --}}
    <div class="text-gray-800">

        {{-- Welcome Message - Ensured light text on dark gradient --}}
        <div class="mb-6 p-4 bg-gradient-to-r from-gray-700 to-gray-800 rounded-lg shadow text-center border border-gray-600">
            {{-- Explicitly setting text color --}}
            <h3 class="text-xl font-semibold text-gray-100"> {{-- Increased size, ensured color --}}
                سلام <span class="font-bold" style="color: var(--clr-gold);">{{ Auth::user()->name }}</span>، عزیز ! به سامانه رایان طلا خوش آمدید
            </h3>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">

            {{-- License Information Card - Light Background with Gold Accent --}}
            <div class="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
                {{-- Card Header --}}
                <div class="px-5 py-3 bg-gray-50 border-b border-gray-200">
                    {{-- Increased header font size --}}
                    <h4 class="text-lg font-semibold text-gray-700 flex items-center"> {{-- text-lg --}}
                        <i class="fas fa-check-circle mr-2 ml-1 text-yellow-500 fa-fw"></i>
                        اطلاعات لایسنس
                    </h4>
                </div>
                {{-- Card Body --}}
                <div class="p-5">
                    {{-- حذف بلاک @php --}}

                    {{-- Increased base font size for card content --}}
                    <div class="space-y-3 text-base text-gray-700"> {{-- text-base --}}
                        @if($licenseData)
                            <div class="flex justify-between items-center">
                                <strong class="font-medium text-gray-500">وضعیت:</strong>
                                @php
                                    // تبدیل status به متن فارسی
                                    $licenseStatusText = match(strtolower($licenseData['status'] ?? 'unknown')) {
                                        'active' => 'فعال',
                                        'expired' => 'منقضی شده',
                                        'suspended' => 'معلق شده',
                                        'pending' => 'در انتظار تایید',
                                        default => 'نامشخص',
                                    };
                                    $licenseStatusClass = match(strtolower($licenseData['status'] ?? 'unknown')) {
                                        'active' => 'bg-green-100 text-green-700',
                                        'expired' => 'bg-red-100 text-red-700',
                                        'suspended' => 'bg-yellow-100 text-yellow-700',
                                        'pending' => 'bg-blue-100 text-blue-700',
                                        default => 'bg-gray-100 text-gray-700',
                                    };
                                @endphp
                                <span class="px-2 py-0.5 rounded text-sm font-bold {{ $licenseStatusClass }}">
                                    {{ $licenseStatusText }}
                                </span>
                            </div>
                            <div class="flex justify-between items-center">
                                <strong class="font-medium text-gray-500">کلید لایسنس:</strong>
                                <span class="font-mono text-sm bg-gray-100 px-2 py-1 rounded text-gray-600">
                                    @if($licenseData['key_display'] !== 'N/A' && strlen($licenseData['key_display']) > 10)
                                        {{ substr($licenseData['key_display'], 0, 5) }}<span class="text-gray-400">...</span>{{ substr($licenseData['key_display'], -5) }}
                                    @else
                                        {{ $licenseData['key_display'] }}
                                    @endif
                                </span>
                            </div>
                            @if($licenseData['expires_at'])
                            <div class="flex justify-between items-center">
                                <strong class="font-medium text-gray-500">تاریخ انقضا:</strong>
                                <span>{{ $licenseData['expires_at'] }}</span>
                            </div>
                            @endif
                        @else
                            <p class="text-gray-500">هنوز لایسنسی برای شما ثبت نشده است.</p>
                        @endif
                    </div>
                </div>
            </div>

            {{-- Version Information Card - Light Background with Gold Accent --}}
            <div class="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
                 {{-- Card Header --}}
                 <div class="px-5 py-3 bg-gray-50 border-b border-gray-200">
                    <h4 class="text-lg font-semibold text-gray-700 flex items-center"> {{-- text-lg --}}
                        <i class="fas fa-cubes mr-2 ml-1 text-yellow-500 fa-fw"></i>
                        اطلاعات نسخه
                    </h4>
                </div>
                 {{-- Card Body --}}
                 <div class="p-5">
                    <div class="space-y-3 text-base text-gray-700"> {{-- text-base --}}
                        <div class="flex justify-between items-center">
                            <strong class="font-medium text-gray-500">نسخه سامانه شما:</strong>
                            <span class="font-semibold px-2 py-0.5 rounded bg-gray-100 text-gray-600 text-sm">{{ $userVersion }}</span> {{-- استفاده از متغیر پاس داده شده --}}
                        </div>
                         <div class="flex justify-between items-center">
                            <strong class="font-medium text-gray-500">آخرین نسخه پایدار:</strong>
                            <span class="font-semibold px-2 py-0.5 rounded bg-gray-100 text-gray-600 text-sm">{{ $latestVersion }}</span> {{-- استفاده از متغیر پاس داده شده --}}
                        </div>

                        {{-- Update Available Section --}}
                        @if ($userVersion !== 'N/A' && $latestVersion !== 'N/A' && version_compare($latestVersion, $userVersion, '>'))
                            <div class="mt-4 pt-4 border-t border-gray-200 text-center">
                                 <p class="text-orange-600 mb-3 text-sm font-semibold"> {{-- text-sm --}}
                                    <i class="fas fa-bell mr-1 animate-pulse"></i> به‌روزرسانی نسخه {{ $latestVersion }} در دسترس است.
                                 </p>
                                {{-- Using btn-gold-app (has white text now) --}}
                                <a href="#" class="btn-gold-app text-sm !py-1.5 !px-4"> {{-- text-sm --}}
                                    مشاهده جزئیات به‌روزرسانی
                                </a>
                            </div>
                        {{-- Up to Date Section --}}
                        @elseif ($userVersion !== 'N/A') {{-- اضافه کردن شرط برای نمایش پیام "به روز است" فقط اگر نسخه کاربر مشخص باشد --}}
                             <div class="mt-4 pt-4 border-t border-gray-200 text-center">
                                 <p class="text-green-600 text-sm font-semibold"> {{-- text-sm --}}
                                    <i class="fas fa-check-circle mr-1"></i> سامانه شما به آخرین نسخه به‌روز می‌باشد.
                                 </p>
                             </div>
                        @endif
                    </div>
                </div>
            </div>

        </div> {{-- End Grid --}}

        {{-- Support Request Section ... (بقیه فایل بدون تغییر) ... --}}
    </div> {{-- End main content wrapper --}}
</x-app-layout>