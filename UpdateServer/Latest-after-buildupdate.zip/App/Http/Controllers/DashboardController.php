<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use App\Models\System;
use App\Models\License;
use Illuminate\Support\Facades\Http; // برای ارسال درخواست HTTP
use Illuminate\Support\Facades\Log; // برای لاگ کردن خطاها

class DashboardController extends Controller
{
    public function index(): View
    {
        $user = Auth::user();
        $licenseData = null;
        $userVersion = 'N/A';
        $latestVersion = 'N/A'; // مقدار پیش‌فرض
        $latestVersionDetails = null; // برای نگهداری کل اطلاعات latest.json

        // 1. واکشی اطلاعات لایسنس کاربر
        if ($user->system) {
            $system = $user->system;
            if ($system && $system->license) {
                $license = $system->license;
                $licenseData = [
                    'status' => $license->status,
                    'key_display' => $license->license_key_display,
                    'expires_at' => $license->expires_at ? $license->expires_at->format('Y-m-d H:i:s') : null,
                ];
            }
            if (isset($system->client_version) && !empty($system->client_version)) {
                $userVersion = $system->client_version;
            }
        }

        // 2. واکشی آخرین نسخه پایدار از latest.json
        $latestJsonUrl = config('app.latest_version_manifest_url'); // آدرس فایل latest.json را در config/app.php تعریف کنید
                                                                  // مثال: 'latest_version_manifest_url' => 'https://yourupdateserver.com/downloads/latest.json',

        if ($latestJsonUrl) {
            try {
                $response = Http::timeout(5)->get($latestJsonUrl); // مهلت ۵ ثانیه
                if ($response->successful()) {
                    $latestVersionDetails = $response->json();
                    if (isset($latestVersionDetails['version'])) {
                        $latestVersion = $latestVersionDetails['version'];
                    }
                } else {
                    Log::warning('Failed to fetch latest version manifest.', [
                        'url' => $latestJsonUrl,
                        'status' => $response->status()
                    ]);
                }
            } catch (\Throwable $e) {
                Log::error('Exception while fetching latest version manifest.', [
                    'url' => $latestJsonUrl,
                    'error' => $e->getMessage()
                ]);
            }
        } else {
            Log::warning('latest_version_manifest_url is not configured in config/app.php.');
        }


        return view('dashboard', [
            'licenseData' => $licenseData,
            'userVersion' => $userVersion,
            'latestVersion' => $latestVersion,
            'latestVersionDetails' => $latestVersionDetails, // می‌توانید کل آبجکت را هم به ویو بفرستید اگر به اطلاعات دیگر نیاز دارید
        ]);
    }
}