<?php

namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
// use App\Models\System; // گرفته شده از request attribute
use App\Models\License;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class ClientLicenseController extends Controller
{
    public function getStatus(Request $request)
    {
        $authenticatedSystem = $request->attributes->get('authenticated_system');
        if (!$authenticatedSystem) {
            return response()->json(['error' => 'System not authenticated or not found.'], 403);
        }

        $license = License::where('system_id', $authenticatedSystem->id)->first();

        if (!$license) {
            return response()->json([
                'status' => 'unlicensed',
                'message' => 'No license is currently associated with this system.',
                'is_active' => false,
            ], 200); // تغییر به 200 با وضعیت unlicensed
        }

        // بررسی وضعیت لایسنس بر اساس فیلد status و تاریخ انقضا
        $isActive = false;
        $statusMessage = $license->status;

        if ($license->status === 'active') {
            if ($license->expires_at && Carbon::parse($license->expires_at)->isPast()) {
                $statusMessage = 'expired';
                $isActive = false;
            } else {
                $isActive = true;
            }
        } else {
            $isActive = false; // for pending, inactive, revoked, etc.
        }


        return response()->json([
            'license_key_display' => $license->license_key_display,
            'status'      => $statusMessage,
            'is_active'   => $isActive,
            'license_type'=> $license->license_type,
            'features'    => $license->features ? json_decode($license->features, true) : [],
            'expires_at'  => $license->expires_at ? Carbon::parse($license->expires_at)->toIso8601String() : null,
            'activated_at'=> $license->activated_at ? Carbon::parse($license->activated_at)->toIso8601String() : null,
        ]);
    }

    public function activate(Request $request)
    {
        $authenticatedSystem = $request->attributes->get('authenticated_system');
        if (!$authenticatedSystem) {
            return response()->json(['error' => 'System not authenticated or not found.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'license_key_display' => 'required|string|max:50',
            // ممکن است نیاز به ارسال hardware_id و request_code هم باشد اگر handshake آنها را تایید نکرده
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $providedLicenseKeyDisplay = $request->input('license_key_display');

        try {
            $license = License::where('license_key_display', $providedLicenseKeyDisplay)->first();

            if (!$license) {
                return response()->json(['error' => 'Invalid license key provided.'], 400);
            }

            // بررسی اینکه لایسنس برای این سیستم است یا هنوز به هیچ سیستمی اختصاص داده نشده
            if ($license->system_id !== null && $license->system_id !== $authenticatedSystem->id) {
                return response()->json(['error' => 'License key is associated with a different system.'], 409);
            }
            
            // اگر لایسنس pending است و به این سیستم (توسط handshake یا فرآیند دیگر) اختصاص داده شده، آن را فعال کن
            if ($license->system_id === $authenticatedSystem->id && $license->status === 'pending') {
                $license->status = 'active';
                $license->activated_at = Carbon::now();
                // اگر expires_at بر اساس نوع لایسنس باید تنظیم شود، اینجا انجام دهید
                // مثال: if ($license->license_type === 'trial' && !$license->expires_at) {
                //          $license->expires_at = Carbon::now()->addDays(30);
                //       }
                $license->save();

                return response()->json([
                    'message' => 'License activated successfully for ' . $authenticatedSystem->name,
                    'license_status' => [
                        'license_key_display' => $license->license_key_display,
                        'status'      => 'active',
                        'is_active'   => true,
                        'expires_at'  => $license->expires_at ? Carbon::parse($license->expires_at)->toIso8601String() : null,
                        'activated_at'=> $license->activated_at->toIso8601String(),
                    ]
                ]);
            } elseif ($license->system_id === $authenticatedSystem->id && $license->status === 'active') {
                return response()->json(['message' => 'License is already active for this system.'], 200);
            } else {
                return response()->json(['error' => 'License cannot be activated for this system or is not in a pending state for it.'], 400);
            }

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error activating license for system ID ' . $authenticatedSystem->id . ': ' . $e->getMessage());
            return response()->json(['error' => 'Could not activate license due to a server error.'], 500);
        }
    }
}