<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\License;
use App\Models\System;
use App\Models\EncryptionKey;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class HandshakeController extends Controller
{
    private function normalizeDomain(string $domain): string {
        $domain = preg_replace('/^https?:\\/\\//i', '', $domain);
        $domain = preg_replace('/^www\\./i', '', $domain);
        return strtolower(trim($domain));
    }

    public function initiate(Request $request)
    {
        $validatedData = $request->validate([
            'license_key_display' => 'required|string|min:8|max:50',
            'domain'              => 'required|string|max:255',
            'ip'                  => 'required|ip',
            'ray_id'              => 'sometimes|string|max:255|nullable',
            'hardware_id'         => 'required|string|max:255',
            'request_code'        => 'required|string|max:255', 
        ]);

        Log::info('Handshake initiated by client.', [
            'license_key_display' => $validatedData['license_key_display'],
            'domain' => $validatedData['domain'],
            'ip' => $validatedData['ip']
        ]);

        $clientLicenseKeyDisplayFull = $validatedData['license_key_display'];
        // Assuming client sends 8 chars + "..." or server stores 8 chars + "..."
        // If client sends full key and server stores 8_char + "...", then server needs to take substr(key,0,8) + "..."
        // If client sends 8_char + "..." and server stores 8_char + "...", direct comparison is fine.
        // Current client logic: $prefix = substr((string)$fullLicenseKeyFromUser, 0, 8); $licenseKeyDisplayToSend = $prefix . '...';
        // So, $clientLicenseKeyDisplayFull from client IS ALREADY in "8char..." format.
        $license = License::where('license_key_display', $clientLicenseKeyDisplayFull)->first(); 

        if (!$license) {
            Log::warning('Handshake failed: License key display not found in DB.', [
                'searched_key_display' => $clientLicenseKeyDisplayFull 
            ]);
            return response()->json(['error' => 'License key not found in our records.'], 404);
        }

        $clientDomainFromRequest = $this->normalizeDomain($validatedData['domain']);
        $storedDomain = null;
        if ($license->system && $license->system->domain) { 
            $storedDomain = $this->normalizeDomain($license->system->domain);
        } elseif ($license->client_domain) { 
            $storedDomain = $this->normalizeDomain($license->client_domain);
        } else {
            Log::error('Handshake failed: No domain configured for the found license.', ['license_id' => $license->id]);
            return response()->json(['error' => 'Domain not configured for this license on server side.'], 500);
        }

        if ($storedDomain !== $clientDomainFromRequest) {
            Log::warning('Handshake domain mismatch after normalization.', [
                'expected_domain_normalized' => $storedDomain,
                'received_domain_normalized' => $clientDomainFromRequest,
                'license_id' => $license->id
            ]);
            return response()->json(['error' => 'Domain validation failed for the provided license.'], 403);
        }
        
        // PBKDF2 Iterations - should match the value used during hash generation in Admin panel
        $pbkdf2_iterations = (int)config('hashing.pbkdf2_iterations', 10000); // Default to 10000 if not in config

        // Validate hardware_id 
        $isHardwareIdValid = false;
        if (isset($license->hardware_id_hash) && isset($license->salt)) {
            $calculatedHardwareIdHash = hash_pbkdf2(
                'sha256',
                $validatedData['hardware_id'], 
                $license->salt, 
                $pbkdf2_iterations,
                0, // length, 0 means default for sha256 which is 32 bytes (64 hex chars)
                false // output raw binary? false for hex string output
            );
            if (hash_equals($license->hardware_id_hash, $calculatedHardwareIdHash)) {
                $isHardwareIdValid = true;
            } else {
                Log::warning('Handshake hardware ID hash mismatch using PBKDF2.', [
                    'license_id' => $license->id,
                    'received_hw_id' => substr($validatedData['hardware_id'],0,10).'...' ,
                    'calculated_hash' => substr($calculatedHardwareIdHash,0,10).'...',
                    'stored_hash' => substr($license->hardware_id_hash,0,10).'...',
                    'iterations_used' => $pbkdf2_iterations
                ]);
            }
        }

        if (!$isHardwareIdValid) {
            Log::warning('Handshake hardware ID validation failed overall.', [
                'license_id' => $license->id,
                'reason' => 'Mismatch or missing hash/salt in DB for hardware ID'
            ]);
            return response()->json(['error' => 'Hardware ID mismatch.'], 403);
        }

        // Validate request_code
        $isRequestCodeValid = false;
        if (isset($license->request_code_hash) && isset($license->salt)) {
            $calculatedRequestCodeHash = hash_pbkdf2(
                'sha256',
                $validatedData['request_code'], 
                $license->salt, 
                $pbkdf2_iterations,
                0,
                false
            );
            if (hash_equals($license->request_code_hash, $calculatedRequestCodeHash)) {
                $isRequestCodeValid = true;
            } else {
                Log::warning('Handshake request code hash mismatch using PBKDF2.', [
                    'license_id' => $license->id,
                    'calculated_hash' => substr($calculatedRequestCodeHash,0,10).'...',
                    'stored_hash' => substr($license->request_code_hash,0,10).'...',
                    'iterations_used' => $pbkdf2_iterations
                ]);
            }
        }

        if (!$isRequestCodeValid) {
            Log::warning('Handshake request code validation failed overall.', [
                'license_id' => $license->id,
                'reason' => 'Mismatch or missing hash/salt in DB for request code'
            ]);
            return response()->json(['error' => 'Request code mismatch.'], 403);
        }

        // Ensure the license is associated with a system_id to proceed
        if (empty($license->system_id)) { 
            Log::error('Handshake failed: License is not associated with a system_id.', ['license_id' => $license->id]);
            return response()->json(['error' => 'Internal server error: License configuration issue.'], 500);
        }
        $targetSystemId = $license->system_id;

        // Generate API keys and handshake string (remains the same)
        $apiKey = Str::random(40);
        $apiSecret = Str::random(60); 
        $hmacSalt = Str::random(32); 
        $handshakeString = $apiKey . $apiSecret . $hmacSalt; // The full string to be stored

        // Store the full handshakeString in the 'key_value' column
        try {
            // Find existing or create new based on system_id
            $encryptionKey = EncryptionKey::firstOrNew(['system_id' => $targetSystemId]);
            
            // Set the values for the columns that actually exist in the table
            $encryptionKey->key_value = $handshakeString; 
            $encryptionKey->status = 'active'; // Set status if applicable
            // created_at and updated_at are usually handled by Eloquent timestamps

            $encryptionKey->save(); // Save the record

        } catch (\Illuminate\Database\QueryException $e) {
            Log::critical('Handshake failed: SQL error during EncryptionKey save with key_value.', [
                'license_id' => $license->id,
                'system_id' => $targetSystemId,
                'error_code' => $e->getCode(),
                'sql_error_message' => $e->getMessage(),
            ]);
            if (str_contains($e->getMessage(), 'foreign key constraint fails')) {
                 Log::error('Foreign key constraint violation for system_id.', ['system_id' => $targetSystemId]);
                 return response()->json(['error' => 'Internal server error: System ID mismatch during credential finalization.'], 500);
            } else if (str_contains($e->getMessage(), 'doesn\'t have a default value') && str_contains($e->getMessage(), 'key_value')) {
                 Log::error('key_value field likely still marked as NOT NULL without default, despite code providing value. Check DB schema.', ['system_id' => $targetSystemId]);
                 return response()->json(['error' => 'Internal server error: Database configuration issue for credentials.'], 500);
            }
            return response()->json(['error' => 'Internal server error while storing handshake credentials.'], 500);
        } catch (\Throwable $e) {
            Log::error('Handshake failed: Generic error during EncryptionKey save with key_value.', [
                'license_id' => $license->id,
                'system_id' => $targetSystemId,
                'error_message' => $e->getMessage(),
            ]);
            return response()->json(['error' => 'Internal server error during credential storage.'], 500);
        }

        // Prepare mapping for the client (remains the same)
        $mapping = [
            'api_key'    => [0, strlen($apiKey) - 1],
            'api_secret' => [strlen($apiKey), strlen($apiKey) + strlen($apiSecret) - 1],
            'hmac_salt'  => [strlen($apiKey) + strlen($apiSecret), strlen($handshakeString) - 1],
        ];

        Log::info('Handshake successful. Handshake string stored in key_value.', [
            'license_id' => $license->id,
            'system_id' => $targetSystemId,
            'client_domain' => $validatedData['domain']
        ]);

        // Send response to client (remains the same)
        return response()->json([
            'message' => 'Handshake successful. Credentials established.',
            'system_id' => $targetSystemId, // <-- این خط اضافه شده است
            'handshake_string' => $handshakeString,
            'handshake_map' => base64_encode(json_encode($mapping)),
            'expires_in' => config('api.security.handshake_token_ttl', 24) * 3600, // Expiry in seconds
        ]);
    } // End initiate method

}