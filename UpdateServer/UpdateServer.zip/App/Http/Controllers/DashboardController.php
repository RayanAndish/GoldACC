<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View; // Import View

class DashboardController extends Controller
{
    /**
     * Display the user's dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index(): View
    {
        // $user = Auth::user(); // Example: Get the authenticated user
        // Add any specific logic here to fetch data for the user dashboard

        // You can pass any data needed for the user dashboard here
        // For example, recent tickets, system status, etc.
        // $recentTickets = $user->tickets()->latest()->take(5)->get();

        return view('dashboard'); // Assuming the view is named 'dashboard.blade.php'
    }
}
