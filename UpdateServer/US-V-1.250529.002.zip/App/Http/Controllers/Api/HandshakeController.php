<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\License;
use App\Models\System;
use App\Models\EncryptionKey;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Cache;
use App\Models\LicenseActivationLog;
use Exception;
use Illuminate\Validation\ValidationException;
use Firebase\JWT\JWT;

class HandshakeController extends Controller
{
    private function normalizeDomain(string $domain): string {
        $domain = preg_replace('/^https?:\\/\\//i', '', $domain);
        $domain = preg_replace('/^www\\./i', '', $domain);
        return strtolower(trim($domain));
    }

    protected $challengeExpiryMinutes = 5;

    public function initiate(Request $request)
    {
        $validatedData = $request->validate([
            'domain' => 'required|string|max:255',
            'ip' => 'required|ip',
            'ray_id' => 'sometimes|string|max:255|nullable',
            'hardware_id' => 'required|string|max:255',
            'client_nonce' => 'required|string|size:32',
            'server_nonce' => 'required|string|size:32',
            'challenge' => 'required|string|size:128'
        ]);

        Log::info('Handshake initiated by client.', [
            'domain' => $validatedData['domain'],
            'ip' => $validatedData['ip'],
            'hardware_id' => $validatedData['hardware_id'],
            'ray_id' => $validatedData['ray_id'] ?? null
        ]);

        try {
            // 1. بازیابی اطلاعات از کش
            $challengeData = Cache::get("activation_challenge_{$validatedData['client_nonce']}");
            
            if (!$challengeData) {
                Log::warning('Challenge not found or expired.', [
                    'client_nonce' => $validatedData['client_nonce']
                ]);
                return response()->json(['error' => 'Challenge expired or invalid'], 400);
            }

            // 2. اعتبارسنجی challenge
            $expectedChallenge = $this->generateChallenge($validatedData['client_nonce'], $validatedData['server_nonce']);
            if (!hash_equals($expectedChallenge, $validatedData['challenge'])) {
                Log::warning('Invalid challenge.', [
                    'client_nonce' => $validatedData['client_nonce'],
                    'server_nonce' => $validatedData['server_nonce']
                ]);
                return response()->json(['error' => 'Invalid challenge'], 403);
            }

            // 3. اعتبارسنجی hardware_id
            if ($challengeData['hardware_id'] !== $validatedData['hardware_id']) {
                Log::warning('Hardware ID mismatch.', [
                    'expected' => $challengeData['hardware_id'],
                    'received' => $validatedData['hardware_id']
                ]);
                return response()->json(['error' => 'Hardware ID mismatch'], 403);
            }

            // 4. اعتبارسنجی domain
            $clientDomain = $this->normalizeDomain($validatedData['domain']);
            $storedDomain = $this->normalizeDomain($challengeData['domain']);
            if ($clientDomain !== $storedDomain) {
                Log::warning('Domain mismatch.', [
                    'expected' => $storedDomain,
                    'received' => $clientDomain
                ]);
                return response()->json(['error' => 'Domain mismatch'], 403);
            }

            // 5. حذف challenge از کش
            Cache::forget("activation_challenge_{$validatedData['client_nonce']}");

            // 6. تولید API keys و handshake string
            $apiKey = Str::random(40);
            $apiSecret = Str::random(60);
            $hmacSalt = Str::random(32);
            $handshakeString = $apiKey . $apiSecret . $hmacSalt;

            // 7. ذخیره در دیتابیس
            try {
                $system = System::create([
                    'hardware_id' => $validatedData['hardware_id'],
                    'domain' => $validatedData['domain'],
                    'ip' => $validatedData['ip'],
                    'status' => 'pending'
                ]);

                $encryptionKey = EncryptionKey::create([
                    'system_id' => $system->id,
                    'key_value' => $handshakeString,
                    'status' => 'active'
                ]);

                Log::info('System and encryption key created successfully.', [
                    'system_id' => $system->id
                ]);

            } catch (\Exception $e) {
                Log::error('Error creating system or encryption key.', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                return response()->json(['error' => 'Internal server error during system setup'], 500);
            }

            // 8. آماده‌سازی پاسخ
            $mapping = [
                'api_key' => [0, strlen($apiKey) - 1],
                'api_secret' => [strlen($apiKey), strlen($apiKey) + strlen($apiSecret) - 1],
                'hmac_salt' => [strlen($apiKey) + strlen($apiSecret), strlen($handshakeString) - 1],
            ];

            Log::info('Handshake successful.', [
                'system_id' => $system->id,
                'domain' => $validatedData['domain']
            ]);

            return response()->json([
                'message' => 'Handshake successful. System registered.',
                'system_id' => $system->id,
                'handshake_string' => $handshakeString,
                'handshake_map' => base64_encode(json_encode($mapping)),
                'expires_in' => config('api.security.handshake_token_ttl', 24) * 3600
            ]);

        } catch (\Exception $e) {
            Log::error('Error in handshake process.', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Internal server error during handshake'], 500);
        }
    }

    public function initiateActivation(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'domain' => 'required|string|max:255',
                'client_nonce' => 'required|string|size:32',
                'hardware_id' => 'required|string|max:64',
                'ip' => 'required|string|max:45',
                'ray_id' => 'required|string|max:64'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input data',
                    'errors' => $validator->errors()
                ], 422);
            }

            $domain = $request->input('domain');
            $clientNonce = $request->input('client_nonce');
            $hardwareId = $request->input('hardware_id');
            $ip = $request->input('ip');
            $rayId = $request->input('ray_id');

            // تولید server_nonce و salt
            $serverNonce = bin2hex(random_bytes(16));
            $salt = bin2hex(random_bytes(32));

            // ذخیره در دیتابیس
            $license = License::create([
                'salt' => $salt,
                'status' => 'pending',
                'license_key_hash' => hash('sha256', uniqid('temp_', true)), // مقدار موقت تا زمان فعال‌سازی واقعی
                'domain' => $domain,
                'client_nonce' => $clientNonce,
                'server_nonce' => $serverNonce,
                'ip_hash' => hash_pbkdf2('sha256', $ip, $salt, config('license.iterations', 10000)),
                'hardware_id' => $hardwareId, // اضافه کردن hardware_id
                'request_code' => null, // مقدار اولیه null
                'activation_date' => null, // مقدار اولیه null
                'expires_at' => null // مقدار اولیه null
            ]);

            // لاگ کردن
            LicenseActivationLog::create([
                'license_id' => $license->id,
                'action_type' => 'initiate',
                'hardware_id' => null, // هنوز تولید نشده
                'domain' => $domain,
                'ip_address' => $ip,
                'ray_id' => $rayId,
                'status' => 'success',
                'message' => 'Activation initiation successful'
            ]);

            return response()->json([
                'success' => true,
                'server_nonce' => $serverNonce,
                'salt' => $salt,
                'ray_id' => $rayId
            ]);

        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid input data',
                'errors' => $e->errors()
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to initiate activation: ' . $e->getMessage()
            ], 500);
        }
    }

    public function activate(Request $request)
    {
        try {
            $this->validate($request, [
                'hardware_id' => 'required|string|max:64',
                'domain' => 'required|string|max:255',
                'request_code' => 'required|string|max:64',
                'ray_id' => 'required|string|size:32'
            ]);

            $hardwareId = $request->input('hardware_id');
            $domain = $request->input('domain');
            $requestCode = $request->input('request_code');
            $rayId = $request->input('ray_id');

            // بررسی وجود لایسنس
            $license = License::where('hardware_id', $hardwareId)
                ->where('domain', $domain)
                ->where('request_code', $requestCode)
                ->where('status', 'pending')
                ->first();

            if (!$license) {
                throw new Exception('Invalid license or request code');
            }

            // بررسی اعتبار request_code
            if (!$this->validateRequestCode($license, $requestCode)) {
                throw new Exception('Invalid request code');
            }

            // تولید توکن فعال‌سازی
            $activationToken = $this->generateActivationToken($license);

            // بروزرسانی وضعیت لایسنس
            $license->update([
                'status' => 'active',
                'activation_date' => now(),
                'activation_token' => $activationToken
            ]);

            // لاگ کردن
            LicenseActivationLog::create([
                'license_id' => $license->id,
                'action_type' => 'activate',
                'hardware_id' => $hardwareId,
                'domain' => $domain,
                'ip_address' => $request->ip(),
                'ray_id' => $rayId,
                'status' => 'success',
                'message' => 'License activated successfully'
            ]);

            return response()->json([
                'success' => true,
                'activation_token' => $activationToken,
                'expires_at' => $license->expires_at
            ]);

        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid input data',
                'errors' => $e->errors()
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to activate license: ' . $e->getMessage()
            ], 500);
        }
    }

    private function generateChallenge($clientNonce, $serverNonce)
    {
        return hash_hmac(
            'sha3-512',
            $clientNonce . $serverNonce,
            config('license.secret')
        );
    }

    private function validateRequestCode(License $license, string $requestCode): bool
    {
        // بررسی اعتبار request_code با استفاده از اطلاعات ذخیره شده
        $expectedCode = hash_hmac('sha256',
            $license->hardware_id . $license->domain . $license->client_nonce . $license->server_nonce,
            $license->salt
        );

        return hash_equals($expectedCode, $requestCode);
    }

    private function generateActivationToken(License $license): string
    {
        // تولید توکن فعال‌سازی با استفاده از اطلاعات لایسنس
        $payload = [
            'license_id' => $license->id,
            'hardware_id' => $license->hardware_id,
            'domain' => $license->domain,
            'expires_at' => $license->expires_at,
            'iat' => time(),
            'nbf' => time()
        ];

        return JWT::encode($payload, config('app.key'), 'HS256');
    }
}