<?php

namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
// use App\Models\System; // گرفته شده از request attribute
use App\Models\License;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class ClientLicenseController extends Controller
{
    public function getStatus(Request $request)
    {
        $authenticatedSystem = $request->attributes->get('authenticated_system');
        if (!$authenticatedSystem) {
            return response()->json(['error' => 'System not authenticated or not found.'], 403);
        }

        $license = License::where('system_id', $authenticatedSystem->id)->first();

        if (!$license) {
            return response()->json([
                'status' => 'unlicensed',
                'message' => 'No license is currently associated with this system.',
                'is_active' => false,
            ], 200); // تغییر به 200 با وضعیت unlicensed
        }

        // بررسی وضعیت لایسنس بر اساس فیلد status و تاریخ انقضا
        $isActive = false;
        $statusMessage = $license->status;

        if ($license->status === 'active') {
            if ($license->expires_at && Carbon::parse($license->expires_at)->isPast()) {
                $statusMessage = 'expired';
                $isActive = false;
            } else {
                $isActive = true;
            }
        } else {
            $isActive = false; // for pending, inactive, revoked, etc.
        }


        return response()->json([
            'license_key_display' => $license->license_key_display,
            'status'      => $statusMessage,
            'is_active'   => $isActive,
            'license_type'=> $license->license_type,
            'features'    => $license->features ? json_decode($license->features, true) : [],
            'expires_at'  => $license->expires_at ? Carbon::parse($license->expires_at)->toIso8601String() : null,
            'activated_at'=> $license->activated_at ? Carbon::parse($license->activated_at)->toIso8601String() : null,
        ]);
    }

    public function activate(Request $request)
    {
        \Illuminate\Support\Facades\Log::info('License activation request received.', [
            'request_data' => $request->all(),
            'system_id' => $request->attributes->get('authenticated_system')?->id
        ]);

        $authenticatedSystem = $request->attributes->get('authenticated_system');
        if (!$authenticatedSystem) {
            \Illuminate\Support\Facades\Log::error('System not authenticated in license activation.');
            return response()->json(['error' => 'System not authenticated or not found.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'license_key_display' => 'required_without:license_key|string|max:50',
            'license_key' => 'required_without:license_key_display|string|max:50',
        ]);

        if ($validator->fails()) {
            \Illuminate\Support\Facades\Log::warning('License activation validation failed.', [
                'errors' => $validator->errors()->toArray()
            ]);
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $providedLicenseKeyDisplay = $request->input('license_key_display') ?? $request->input('license_key');
        \Illuminate\Support\Facades\Log::info('Looking up license.', [
            'license_key_display' => $providedLicenseKeyDisplay
        ]);

        try {
            $license = License::where('license_key_display', $providedLicenseKeyDisplay)->first();

            if (!$license) {
                \Illuminate\Support\Facades\Log::warning('License not found.', [
                    'license_key_display' => $providedLicenseKeyDisplay
                ]);
                return response()->json(['error' => 'Invalid license key provided.'], 400);
            }

            \Illuminate\Support\Facades\Log::info('License found.', [
                'license_id' => $license->id,
                'system_id' => $license->system_id,
                'status' => $license->status,
                'authenticated_system_id' => $authenticatedSystem->id,
                'hardware_id_hash_exists' => !empty($license->hardware_id_hash),
                'salt_exists' => !empty($license->salt),
                'request_code_hash_exists' => !empty($license->request_code_hash),
                'license_key_display' => $license->license_key_display
            ]);

            // بررسی اینکه لایسنس برای این سیستم است یا هنوز به هیچ سیستمی اختصاص داده نشده
            if ($license->system_id !== null && (string)$license->system_id !== (string)$authenticatedSystem->id) {
                \Illuminate\Support\Facades\Log::warning('License belongs to different system.', [
                    'license_system_id' => $license->system_id,
                    'request_system_id' => $authenticatedSystem->id,
                    'license_status' => $license->status,
                    'license_id' => $license->id
                ]);
                return response()->json(['error' => 'License key is associated with a different system.'], 409);
            }
            
            // اگر لایسنس pending است، آن را فعال کن
            if ($license->status === 'pending') {
                \Illuminate\Support\Facades\Log::info('Activating license.', [
                    'license_id' => $license->id,
                    'system_id' => $authenticatedSystem->id
                ]);

                $license->status = 'active';
                $license->system_id = $authenticatedSystem->id;
                $license->activated_at = Carbon::now();
                $license->save();

                \Illuminate\Support\Facades\Log::info('License activated successfully.', [
                    'license_id' => $license->id,
                    'system_id' => $authenticatedSystem->id
                ]);

                return response()->json([
                    'message' => 'License activated successfully for ' . $authenticatedSystem->name,
                    'license_status' => [
                        'license_key_display' => $license->license_key_display,
                        'status'      => 'active',
                        'is_active'   => true,
                        'expires_at'  => $license->expires_at ? Carbon::parse($license->expires_at)->toIso8601String() : null,
                        'activated_at'=> $license->activated_at->toIso8601String(),
                    ]
                ]);
            } else if ($license->system_id === $authenticatedSystem->id && $license->status === 'active') {
                \Illuminate\Support\Facades\Log::info('License already active.', [
                    'license_id' => $license->id,
                    'system_id' => $authenticatedSystem->id
                ]);
                return response()->json(['message' => 'License is already active for this system.'], 200);
            } else {
                \Illuminate\Support\Facades\Log::warning('License cannot be activated.', [
                    'license_id' => $license->id,
                    'system_id' => $license->system_id,
                    'status' => $license->status,
                    'authenticated_system_id' => $authenticatedSystem->id
                ]);
                return response()->json(['error' => 'License cannot be activated for this system or is not in a pending state for it.'], 400);
            }

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error activating license.', [
                'system_id' => $authenticatedSystem->id,
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Could not activate license due to a server error.'], 500);
        }
    }
}